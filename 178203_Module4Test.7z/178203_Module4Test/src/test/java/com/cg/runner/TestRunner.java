package com.cg.runner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		features={"C:\\Users\\nehadesh\\Desktop\\Selenium\\178203_Module4Test\\src\\test\\java\\com\\cg\\feature"}
		,glue= {"com.cg.stpdef"}
		//features="com.cg.feature",glue= {"com.cg.stepdef"}
		
		,monochrome=true
		,tags= {"@smoke"}		
//		,dryRun=true
		)
public class TestRunner
{    

}

 
