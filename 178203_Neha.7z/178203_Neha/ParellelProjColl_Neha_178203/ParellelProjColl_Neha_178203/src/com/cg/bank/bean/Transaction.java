package com.cg.bank.bean;

import java.time.LocalDate;

public class Transaction {
	private int Account_number;
	private Double Amount;
	private int balance;
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	LocalDate date;
	
	public Transaction(int account_number, Double amount, int balance, LocalDate date) {
		super();
		Account_number = account_number;
		Amount = amount;
		this.balance = balance;
		this.date = date;
	}
	public int getAccount_number() {
		return Account_number;
	}
	public void setAccount_number(int account_number) {
		Account_number = account_number;
	}
	public Double getAmount() {
		return Amount;
	}
	public void setAmount(Double amount) {
		Amount = amount;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Transaction [Account_number=" + Account_number + ", Amount=" + Amount + ", balance=" + balance
				+ ", date=" + date + "]";
	}
	

}
