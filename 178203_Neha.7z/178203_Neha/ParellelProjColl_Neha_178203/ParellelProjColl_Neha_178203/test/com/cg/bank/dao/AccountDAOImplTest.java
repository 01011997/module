package com.cg.bank.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AccountDAOImplTest {
	
	AccountDAOImpl dao=null;

	@Before
	public void setUp() throws Exception {
		dao=new AccountDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		
		dao=null;
	}

	
}
