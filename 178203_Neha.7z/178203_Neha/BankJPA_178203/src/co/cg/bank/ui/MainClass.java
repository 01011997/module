package co.cg.bank.ui;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import co.cg.bank.bean.Bank;
import co.cg.bank.bean.Transaction;
import co.cg.bank.exception.BankException;
import co.cg.bank.service.BankService;
import co.cg.bank.service.BankServiceImpl;

public class MainClass {

	public static void main(String[] args) throws BankException {
		BankService service = new BankServiceImpl();
		Scanner scan = null;
		String continueChoice = "";
		String name, mobno,Aadharno;
		
		System.out.println("*********Banking Application********");

		do {
	
							
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit");
		System.out.println("4.Withdraw");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Print Transactions");
		System.out.println("7.Exit");
		
		System.out.println("Enter your choice:");
		
		try {
			scan = new Scanner(System.in);
			int choice = scan.nextInt();
			
			switch (choice) {
			
			
			case 1:
				
				Bank bank = new Bank();
				boolean nameFlag = false;
				
				do {
				System.out.println("Enter your Name:");
				name = scan.next();
				bank.setName(name);
						
				try {		
					service.validateName(name);
					nameFlag = true;
					
				}catch(BankException e) {
					nameFlag = false;
					System.err.println(e.getMessage());				
				}
				}while(!nameFlag);
				
				boolean mobFlag = false;
				do {
				System.out.println("Enter your Mobile Number:");
				mobno = scan.next();
				bank.setMobno(mobno);
				
				try {
					
					service.validateMobile(mobno);
					mobFlag = true;
					
				}catch(BankException e) {
					mobFlag = false;
					System.err.println(e.getMessage());
					
				}
				}while(!mobFlag);
				
				boolean aadharFlag = false;
				do {
				System.out.println("Enter your Aadhar Number:");
				Aadharno = scan.next();
				bank.setAadharno(Aadharno);
				
				try {
					
					service.validateAadhar(Aadharno);
					aadharFlag = true;
					
				}catch(BankException e) {
					aadharFlag = false;
					System.err.println(e.getMessage());
					
				}
				}while(!aadharFlag);
				Bank banks= new Bank(name,mobno,Aadharno);
				int accountno=(int) (Math.random()*10000);
				banks.setAccountno(accountno);
				System.out.println("Account created Successfully with Account No: "+ accountno);
				service.addNewAccount(banks);
				break;
				
			case 2:
				
				System.out.println("Enter your Account Number");
				int check_no = scan.nextInt();
				double balance = service.checkBalance(check_no);
				System.out.println("Current Balance is:"+balance);
				double walletbalance = service.checkWalletBalance(check_no);
				System.out.println("Wallet Balance is:"+walletbalance);


				break;
				
			case 3:
	
				System.out.println("Enter your Account Number");
				int accountno1 = scan.nextInt();
				System.out.println("Enter the amount you want to deposit: ");
				int amount = scan.nextInt();
				double depositAmount = service.deposit(accountno1, amount);
				System.out.println("Current Balance is: "+depositAmount);
				break;
	
			case 4:
	
				System.out.println("Enter your Account Number");
				int  account2 = scan.nextInt();
				System.out.println("Enter the amount you want to withdraw");
				int amount1 = scan.nextInt();
				double withdrawAmount = service.withdraw(account2,amount1);
				System.out.println("Current Balance is: "+withdrawAmount);

				break;
	
			case 5:
				
				/*int sender_no,recipient_no,transferamount;
				System.out.println("Enter your Account Number");
				sender_no = scan.nextInt();
				System.out.println("Enter Recipients Number");
				recipient_no = scan.nextInt();
				System.out.println("Enter Amount you want to transfer");
				transferamount = scan.nextInt();
				String fund = service.fundTransfer(sender_no,recipient_no,transferamount);
				
				System.out.println(fund);
				System.out.println();
				break;
				*/
				System.out.println("1.Account to wallet\n2.wallet to account\n3.Wallet to wallet");
				int c=0;
				c=scan.nextInt();
				switch(c) {
				
				
				case 1:
					int Account_number1; 
					double amount11;
					System.out.println("Enter Account Number: ");
					Account_number1=scan.nextInt();
					System.out.println("Enter Amount to Transfer: ");
					amount11=scan.nextDouble();
					String str1=service.Accounttowallet(Account_number1,amount11);
					System.out.println(str1);
					break;
				case 2:
					int Account_number2; 
					double amount2;
					System.out.println("Enter Account Number: ");
					Account_number2=scan.nextInt();
					System.out.println("Enter Amount to Transfer: ");
					amount2=scan.nextDouble();
					String str2=service.WalletToAccount(Account_number2,amount2);
					System.out.println(str2);
					break;
					
				case 3:
					int Account_number3,reciever_account_number; 
					double amount4;
					System.out.println("Enter Account Number: ");
					Account_number3=scan.nextInt();
					System.out.println("Enter Receiver Account Number: ");
					reciever_account_number=scan.nextInt();
					System.out.println("Enter Amount to Transfer: ");
					amount4=scan.nextDouble();
					String str=service.fundTransfer(Account_number3,reciever_account_number,amount4);
					System.out.println(str);
					break;
				
				}
		break;
	
			case 6:
	
				System.out.println("Enter your Account Number");
				accountno = scan.nextInt();
				List<Transaction> list = service.printTransaction(accountno);
				list.stream().forEach(System.out::println);
				break;
	

			case 7:
				System.out.println("Exiting, Thank You!");
				System.exit(0);
				break;

			default:
				System.out.println("Please enter valid option");
				break;
			}
			
			
			
		}catch(InputMismatchException | SQLException e) {
			System.err.println("Enter only digits");
		}
		
		System.out.println("Do you want to continue? Yes|No: ");
		continueChoice = scan.next();
		}while(continueChoice.equalsIgnoreCase("yes"));
	}

}
