package co.cg.bank.bean;

public class Wallet {

	private int Accountno;
	private double wallet_balance;
	
	public int getAccountno() {
		return Accountno;
	}
	public void setAccountno(int accountno) {
		Accountno = accountno;
	}
	public double getWallet_balance() {
		return wallet_balance;
	}
	public void setWallet_balance(double wallet_balance) {
		this.wallet_balance = wallet_balance;
	}
	public Wallet(int accountno, double wallet_balance) {
		super();
		Accountno = accountno;
		this.wallet_balance = wallet_balance;
	}
	@Override
	public String toString() {
		return "Wallet [Accountno=" + Accountno + ", wallet_balance=" + wallet_balance + "]";
	}
	
}
