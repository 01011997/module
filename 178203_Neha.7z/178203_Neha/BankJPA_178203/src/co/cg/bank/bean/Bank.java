package co.cg.bank.bean;

public class Bank {

	private String name;
	private String mobno;
	private String Aadharno;
	private int Accountno;
	private double balance;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	public String getAadharno() {
		return Aadharno;
	}
	public void setAadharno(String aadharno) {
		Aadharno = aadharno;
	}
	
	public int getAccountno() {
		return Accountno;
	}
	public void setAccountno(int accountno) {
		Accountno = accountno;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double amountAfterWithdraw) {
		this.balance = amountAfterWithdraw;
	}
	public Bank(String name, String mobno, String aadharno, int accountno, int balance) {
		super();
		this.name = name;
		this.mobno = mobno;
		Aadharno = aadharno;
		Accountno = accountno;
		this.balance = balance;
	}
	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Bank(String name, String mobno, String aadharno) {
		super();
		this.name = name;
		this.mobno = mobno;
		Aadharno = aadharno;
	}
	@Override
	public String toString() {
		return "Bank [name=" + name + ", mobno=" + mobno + ", Aadharno=" + Aadharno + ", Accountno=" + Accountno
				+ ", balance=" + balance + "]";
	}
	
	
	
}
