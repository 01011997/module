package co.cg.bank.bean;

import java.time.LocalDate;

public class Transaction {

	private int Accountno;
	private double amount;
	LocalDate date;


	public int getAccountno() {
		return Accountno;
	}
	public void setAccountno(int accountno) {
		Accountno = accountno;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public Transaction(int accountno, double amount, LocalDate date) {
		super();
		Accountno = accountno;
		this.amount = amount;
		this.date = date;
	}
	@Override
	public String toString() {
		return "Transaction [Accountno=" + Accountno + ", amount=" + amount + ", date=" + date + "]";
	}
	
	
}
