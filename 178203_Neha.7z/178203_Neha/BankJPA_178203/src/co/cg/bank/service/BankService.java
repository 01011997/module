package co.cg.bank.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import co.cg.bank.bean.Bank;
import co.cg.bank.bean.Transaction;
import co.cg.bank.exception.BankException;

public interface BankService {

	void validateName(String name) throws BankException;

	void validateMobile(String mobno) throws BankException;

	void validateAadhar(String aadharno) throws BankException;

	double checkBalance(int check_no) throws SQLException, BankException;

	double deposit(int accountno1, int amount) throws SQLException, BankException;

	double withdraw(int account2, int amount1) throws SQLException, BankException;
	Map<Integer,Bank>displayAccountDetails();
	public void addNewAccount(Bank bank) throws SQLException ;

	String fundTransfer(int sender_no, int recipient_no, double amount4) throws SQLException;

	String Accounttowallet(int account_number5, double amount11) throws SQLException;

	String WalletToAccount(int account_number2, double amount2) throws SQLException;

	List<Transaction> printTransaction(int accountno) throws BankException;

	double checkWalletBalance(int check_no) throws SQLException;
}
