package co.cg.bank.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import co.cg.bank.bean.Bank;
import co.cg.bank.bean.Transaction;
import co.cg.bank.dao.BankDAO;
import co.cg.bank.dao.BankDAOImpl;
import co.cg.bank.exception.BankException;

public class BankServiceImpl implements BankService {

	BankDAO dao = new BankDAOImpl();
	@Override
	public void validateName(String name) throws BankException {
		String nameRegEx = "[a-zA-Z ]+";
		if (Pattern.matches(nameRegEx, name) == false) {
			throw new BankException("name should contain only alphabets");
	}
	}

	@Override
	public void validateMobile(String mobno) throws BankException {
		String phoneRegEx = "[7|8|9]{1}[0-9]{9}";
		if (Pattern.matches(phoneRegEx, mobno) == false) {
			throw new BankException("mobile number should contain exactly 10 digits and should start with 7,8,9 ");
		}		
	}

	@Override
	public void validateAadhar(String aadharno) throws BankException {
		String aadharRegEx = "[0-9]{12}";
		if (Pattern.matches(aadharRegEx, aadharno) == false) {
			throw new BankException("Aadhar number should contain exactly 12 digits");
		}	
	}

	@Override
	public double checkBalance(int check_no) throws SQLException, BankException{
		return dao.checkBalance(check_no);
	}

	@Override
	public double deposit(int accountno1, int amount) throws SQLException, BankException {
		return dao.deposit(accountno1, amount);
	}

	@Override
	public double withdraw(int account2, int amount1) throws SQLException, BankException {
		return dao.withdraw(account2,amount1);
	}

	@Override
	public Map<Integer, Bank> displayAccountDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addNewAccount(Bank bank) throws SQLException {
		dao.addNewAccount(bank);
	}


	@Override
	public String Accounttowallet(int account_number5, double amount11) throws SQLException {
		String account1 = dao.Accounttowallet(account_number5, amount11);
		return account1;
	}

	@Override
	public String WalletToAccount(int account_number2, double amount2) throws SQLException {
		String account2 = dao.walletToAccount(account_number2,amount2);
		return account2;
	}


	@Override
	public String fundTransfer(int sender_no, int recipient_no, double amount4) throws SQLException {
		String str1= dao.fundTransfer(sender_no,recipient_no,amount4);
		return str1;
	}

	@Override
	public List<Transaction> printTransaction(int accountno) throws BankException {
		return dao.printTransaction(accountno);
	}

	@Override
	public double checkWalletBalance(int check_no) throws SQLException {
		return dao.checkWalletBalance(check_no);

	}
	
}
