package co.cg.bank.dao;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import co.cg.bank.bean.Bank;
import co.cg.bank.bean.Transaction;
import co.cg.bank.bean.Wallet;
import co.cg.bank.exception.BankException;


public class BankDAOImpl implements BankDAO {
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
	EntityManager em = emf.createEntityManager();

	Map<Integer,Bank> account=new HashMap<Integer,Bank>();
	Map<Integer,Wallet> wallet=new HashMap<Integer,Wallet>();
List<Transaction> transaction=new ArrayList<Transaction>();
Wallet w=null;
	

	public void addnewAccount(Bank b){
		em.getTransaction().begin();
		em.persist(b);
		
		em.getTransaction().commit();
		System.out.println(b.getAccountno());
		
	}
	public double CheckBalance(int account_number1) {
		Bank bank = em.find(Bank.class, account_number1);
		return bank.getBalance();
	}


	@Override
	public double deposit(int accountno1, int amount) throws BankException {
		em.getTransaction().begin();
		Bank bank = em.find(Bank.class, accountno1);
		bank.setBalance((int) (bank.getBalance() + amount));
		em.persist(bank);
		em.getTransaction().commit();
		return bank.getBalance();
	}
	
	@Override
	public double withdraw(int account2, int amount1) throws BankException {
		em.getTransaction().begin();
		Bank bank = em.find(Bank.class, account2);
		bank.setBalance((int) (bank.getBalance() - amount1));
		em.persist(bank);
		em.getTransaction().commit();
		return bank.getBalance();
	}
	@Override
	public String fundTransfer(int sender_no, int recipient_no, double amount4) {
	
		em.getTransaction().begin();
		Bank bank = em.find(Bank.class, sender_no);
		Bank c1 = em.find(Bank.class, recipient_no);
		bank.setBalance((int) (bank.getBalance()-amount4));
		bank.setBalance((int) (bank.getBalance()+amount4));
		em.persist(bank);
		em.getTransaction().commit();
		return "Amount transfered";

	}
	@Override
	public List<Transaction> printTransaction(int accountno) throws  BankException{

		Query q = em.createQuery("Select h from History h B accountId =?");
		q.setParameter(1, accountno);
		List list=q.getResultList();
		return list;
	}
	@Override
	public String Accounttowallet(int account_number5, double amount11) {
		em.getTransaction().begin();
		Bank bank = em.find(Bank.class, account_number5);
		bank.setBalance(bank.getBalance()- amount11);
		Wallet w= em.find(Wallet.class, account_number5);
		w.setWallet_balance(w.getWallet_balance()+amount11);
		em.persist(bank);
		em.persist(w);
		em.getTransaction().commit();
		return "Amount transfered from account to wallet";

	}
	@Override
	public String walletToAccount(int account_number2, double amount2) {
		em.getTransaction().begin();
		Bank c = em.find(Bank.class, account_number2);
		Wallet w = em.find(Wallet.class, account_number2);
		w.setWallet_balance(w.getWallet_balance()-amount2);
		c.setBalance(c.getBalance()+ amount2);
		em.persist(w);
		em.persist(c);
		em.getTransaction().commit();
		return "Amount transfered from wallet to account";
		
	}
	@Override
	public double checkWalletBalance(int check_no) {
		Bank c = em.find(Bank.class, check_no);
		c.setBalance(c.getBalance());
		em.getTransaction().commit();
		return c.getBalance();
	}
	@Override
	public double checkBalance(int check_no) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int addNewAccount(Bank bank) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	}

