package co.cg.bank.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import co.cg.bank.bean.Bank;
import co.cg.bank.bean.Transaction;
import co.cg.bank.exception.BankException;

public interface BankDAO {

	double checkBalance(int check_no) throws SQLException;

	double deposit(int accountno1, int amount) throws SQLException, BankException;

	double withdraw(int account2, int amount1) throws SQLException, BankException;
	public int addNewAccount(Bank bank) throws SQLException;

	//public Map<Integer, Bank> displayAccountDetails();

	String fundTransfer(int sender_no, int recipient_no, double amount4) throws SQLException;

	String Accounttowallet(int account_number5, double amount11) throws SQLException;

	String walletToAccount(int account_number2, double amount2) throws SQLException;

	List<Transaction> printTransaction(int accountno) throws BankException;

	double checkWalletBalance(int check_no) throws SQLException;

	//int addnewAccount(Bank b) throws SQLException;
}
