package co.cg.bank.util;

import java.util.HashMap;
import java.util.Map;

import co.cg.bank.bean.Bank;

public class BankUtil {
	public static Map<Integer,Bank> bankMap=new HashMap<Integer,Bank>();
	
	public static Map<Integer,Bank> getBankMap() {
		return bankMap;
	}
	
	public static void setBankList(Map<Integer,Bank> bankMap) {
		BankUtil.bankMap = bankMap;
	}
}
