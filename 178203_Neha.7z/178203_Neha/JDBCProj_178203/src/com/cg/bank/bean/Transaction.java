package com.cg.bank.bean;

import java.sql.Date;
import java.time.LocalDate;

public class Transaction {
	private int Account_number;
	private Double Amount;
	Date date;
	public Transaction(int account_number, Double amount, Date date) {
		super();
		Account_number = account_number;
		Amount = amount;
		this.date = date;
	}
	
	public int getAccount_number() {
		return Account_number;
	}
	public void setAccount_number(int account_number) {
		Account_number = account_number;
	}
	public Double getAmount() {
		return Amount;
	}
	public void setAmount(Double amount) {
		Amount = amount;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Transaction [Account_number=" + Account_number + ", Amount=" + Amount + ", date=" + date + "]";
	}
	

}
