package com.cg.bank.exception;

public class AccountException extends Exception{
	public AccountException(String Message) {
		super(Message);
	}

}
