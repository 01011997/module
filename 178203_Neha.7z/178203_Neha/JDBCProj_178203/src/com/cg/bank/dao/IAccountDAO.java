package com.cg.bank.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.exception.AccountException;

public interface IAccountDAO {

	public double getaccountbalance(int account_number) throws SQLException;
	public double getwalletbalance(int account_number) throws SQLException;

	double deposite(int Account_number11, double depositeamount) throws  SQLException;

	double withdraw(int account_number111, double amountwithdraw) throws SQLException;
	public int addnewAccount(Account a) throws SQLException;

	String Wallettowallet(int account_number4, int reciever_account_number, double amount1) throws SQLException;

	String Accounttowallet(int account_number5, double amount11) throws SQLException;

	String Wallettoaccount(int account_number6, double amount2) throws SQLException;
	public List<Transaction> printtransaction(int account_number) throws SQLException;
	


}
