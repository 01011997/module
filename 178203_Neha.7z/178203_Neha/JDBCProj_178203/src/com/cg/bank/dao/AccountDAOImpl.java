package com.cg.bank.dao;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;

import com.cg.bank.exception.AccountException;

public class AccountDAOImpl implements IAccountDAO {
	Map<Integer,Account> account=new HashMap<Integer,Account>();	
	List<Transaction> transaction=new ArrayList<Transaction>(); 
	
	static Connection c;
	public AccountDAOImpl() {
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			if(c==null) {
				c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "System", "India123");
			System.out.println("Connected"+c);
			}
		}catch(Exception e) {
			System.out.println(e);
	}
	}
	
	public int addnewAccount(Account a) throws SQLException{
		PreparedStatement pst=c.prepareStatement("insert into Account values(?,?,?,?,?,?)");
		pst.setInt(1, a.getAccount_number());
		pst.setString(2, a.getUsername());
		pst.setString(3, a.getMobileNo());
		pst.setString(4, a.getPassword());
		pst.setDouble(5,0);
		pst.setDouble(6,0);
		pst.executeQuery();
		
		Transaction t= new Transaction(0, null, null);
		t.setAccount_number(a.getAccount_number());
		t.setAmount(a.getBalance());
		t.setDate(Date.valueOf(LocalDate.now()));	
		transaction.add(t);
		
		PreparedStatement ps1=c.prepareStatement("Select Account_number from Account where account_number=?");
		ps1.setInt(1, a.getAccount_number());
		ResultSet rs=ps1.executeQuery();
		if(rs.next()) 
			rs.getInt(1);
		
		return 0;
		
		//putTransactions(a.getAccount_number(), "created account", a.getBalance());
		
	
	}
	
	
	@Override
	public double getaccountbalance(int account_number) throws SQLException {

		PreparedStatement ps=c.prepareStatement("Select balance from Account where account_number=?");
		ps.setInt(1, account_number);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
			return rs.getDouble(1);
		else return -1;
	}
	@Override
	public double getwalletbalance(int account_number) throws SQLException {
		
		PreparedStatement ps=c.prepareStatement("Select wallet_balance from Account where account_number=?");
		ps.setInt(1, account_number);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
			return rs.getDouble(1);
		return rs.getDouble(1);
	}
	
	@Override
	public double deposite(int Account_number11, double depositeamount) throws SQLException  {
	
PreparedStatement ps=c.prepareStatement("update account set balance=balance+? where account_number=?");
		
		ps.setDouble(1, depositeamount);
		ps.setInt(2, Account_number11);
		ps.executeQuery();
		return depositeamount;
		
		//putTransactions(Account_number11, "Deposited Money", depositeamount);
	}

	@Override
	public double withdraw(int account_number111, double amountwithdraw) throws SQLException {
		
    PreparedStatement ps=c.prepareStatement("update account set balance=balance-? where account_number=?");
		
		ps.setDouble(1, amountwithdraw);
		ps.setInt(2, account_number111);
		ps.executeQuery();
		return amountwithdraw;
	}
	@Override
	public String Wallettowallet(int account_number4, int reciever_account_number, double amount1) throws SQLException {
		PreparedStatement ps=c.prepareStatement("update account set wallet_balance=wallet_balance-? where account_number=?");
		ps.setDouble(1, amount1);
		ps.setInt(2, account_number4);
		ps.executeQuery();
		
		ps=c.prepareStatement("update account set wallet_balance=wallet_balance+? where account_number=?");
		ps.setDouble(1, amount1);
		ps.setInt(2, reciever_account_number);
		ps.executeQuery();
		return "Transferred";
		//putTransactions(account_number4, "walletToWallet", amount1);
	}
	@Override
	public String Accounttowallet(int account_number5, double amount11) throws SQLException {
PreparedStatement ps=c.prepareStatement("update account set balance=balance-? where account_number=?");
		
		ps.setDouble(1, amount11);
		ps.setInt(2, account_number5);
		ps.executeQuery();
		
		
		ps=c.prepareStatement("update account set wallet_balance=wallet_balance+? where account_number=?");
		
		ps.setDouble(1, amount11);
		ps.setInt(2, account_number5);
		ps.executeQuery();
		return "Transferred";
		//putTransactions(account_number5, "Account To wallet", amount11);

	}
	@Override
	public String Wallettoaccount(int account_number6, double amount2) throws SQLException {
PreparedStatement ps=c.prepareStatement("update account set balance=balance+? where account_number=?");	
		ps.setDouble(1, amount2);
		ps.setInt(2, account_number6);
		ps.executeQuery();	
		ps=c.prepareStatement("update account set wallet_balance=wallet_balance-? where account_number=?");		
		ps.setDouble(1, amount2);
		ps.setInt(2, account_number6);
		ps.executeQuery();
		return "Transferred";
		//putTransactions(account_number6, "wallet To bank", amount2);
	}
	@Override
	public List<Transaction> printtransaction(int account_number) throws SQLException {
		/*List<Transaction> list= new ArrayList<Transaction>();
		for(Transaction t:transaction)
			if(t.getAccount_number()==account_number) {
				list.add(t);
			}
		return list;*/
		List<Transaction> list = new ArrayList<Transaction>();
		PreparedStatement ps = AccountDAOImpl.c.prepareStatement("Select * from Transaction where account_number=?");
		ps.setInt(1, account_number);
		Transaction t;
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			t = new Transaction(account_number, null, null);
			t.setAccount_number(rs.getInt(1));
			t.setAmount(rs.getDouble(2));
			t.setDate(rs.getDate(3));
			list.add(t);
		}
		return list;
		
		/*public void  putTransactions(int account_number1, String operation, double amount) throws SQLException throws SQLException{

			Account a=new Account();
			Trabsaction t=null;
			PreparedStatement ps = BankDaoImpl.c.prepareStatement("Select * from Account where account_number=?");
			ps.setInt(1, account_number);
			ResultSet rs = ps.executeQuery();		
			if (rs.next()) {
				a.setAccount_number(rs.getInt(1));
				a.setUsername(rs.getString(2));
				a.setPassword(rs.getString(3));
				a.setMobileNo(rs.getString(4));
				a.setBalance(rs.getDouble(5));
				a.setWallet_Balance(rs.getDouble(6));
		
			}
	
			Transaction t=new Transaction();
			t.setAccount_number(a.getAccount_number());
			t.setAmount(a.getBalance());
			t.setDate(Date.valueOf(LocalDate.now()));
				
			ps = BankDaoImpl.c.prepareStatement("insert into transaction values(?,?,?,?,?,?)");
			ps.setInt(1, t.getAccount_number());
			ps.setDouble(2, t.getBalance());
			ps.setDate(3, t.getDate());
			ps.executeQuery();
			
		}
*/
	
	}
	
	}

	

	
	


	

