package com.cg.bank.ui;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.exception.AccountException;
import com.cg.bank.service.AccountServiceImpl;
import com.cg.bank.service.IAccountService;

public class AccountMain {
	public static void main(String[] args) {
		Scanner scan=null;
		Scanner scan1=null;
		
		IAccountService service= new AccountServiceImpl();
		Account account=null;
		String ContinueChoice="";
		do {
			System.out.println(" Welcome to Mobile App ");	
			System.out.println("*******************************");
			System.out.println("1.Create Account\n2.Show Balance\n3.Deposite\n4.Withdraw\n5.Fund Transfer\n6.Print Transaction\n7.Exit");
			System.out.println("*******************************");
			
			int choice =0;
			boolean choiceFlag=false;
			do {
				scan=new Scanner(System.in);
				System.out.println("Enter your Choice");
				try {
					choice=scan.nextInt();
					choiceFlag=true;
					switch(choice) {
					case 1:
				             	String Username="";
									boolean UsernameFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Username");
										try {
										Username=scan1.nextLine();
										service.validateUserName(Username);	
										UsernameFlag=true;
										break;
										}catch(AccountException e) {
											UsernameFlag=false;
											System.out.println(e.getMessage());
										}
									}while(!UsernameFlag);
									String Password="";
									boolean PasswordFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Password");
										try {
										Password=scan1.nextLine();
										service.validatePassword(Password);	
										PasswordFlag=true;
										break;
										}catch(AccountException e) {
											PasswordFlag=false;
											System.out.println(e.getMessage());
										}
									}while(!PasswordFlag);
									String MobileNo="";
									boolean  MobileNoFlag=false;
									do {
										scan1=new Scanner(System.in);
										System.out.println("Enter Mobile number");
										try {
											 MobileNo=scan1.nextLine();
										service.validateMobileNo(MobileNo);	
										 MobileNoFlag=true;
										break;
										}catch(AccountException e) {
											 MobileNoFlag=false;
											System.out.println(e.getMessage());
										}
									}while(! MobileNoFlag);
									
									Account a=new Account(Username, Password,MobileNo);
									int Account_number=(int) (Math.random()*1000*1000);
									System.out.println("Account created Successfully with Account number"+ Account_number);
									a.setAccount_number(Account_number);
									/*Wallet w=new Wallet(Account_number);
									w.setAccount_number(Account_number);*/
						try {
							service.addnewAccount(a);
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
									break;
								case 2:
									int Account_number1 = 0;
									boolean Account_numberFlag = false;
									do {
										scan = new Scanner(System.in);
										System.out.println("Enter Account number");
										try {
											Account_number1 = scan.nextInt();
											service.validateAccount_number(Account_number1);						
											Account_numberFlag = true;
											break;

										} catch (InputMismatchException e) {
											Account_numberFlag = false;
											System.err.println(e.getMessage());
										} catch (AccountException e) {
											System.err.println(e.getMessage());
										}

									} while (!Account_numberFlag);
						try {
							System.out.println("Account Balance ="+service.getaccountbalance(Account_number1));
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
								
						try {
							System.out.println("Wallet Balance ="+service.getwalletbalance(Account_number1));
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
									break;
								
								case 3:
									//For Deposit
									System.out.println("You want to deposit amount in your account...\nEnter Account Number..");
									int Account_number11=scan.nextInt();
									System.out.println("Now enter the amount for deposit");
									double depositeamount=scan.nextDouble();
						double amountAfterDeposite = 0d;
						try {
							amountAfterDeposite = service.deposite(Account_number11,depositeamount);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
									System.out.println("New Balance: "+amountAfterDeposite);
									break;
								case 4:
									//For Deposit
									System.out.println("You want to withdraw from your account\n Enter your account number");
									int Account_number111=scan.nextInt();
									System.out.println("Now enter the amount for withdraw");
									double amountwithdraw=scan.nextDouble();
						double amountAfterDeposite1 = 0d;
						
							try {
								amountAfterDeposite1 = service.withdraw(Account_number111,amountwithdraw);
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						
									System.out.println("New Balance: "+amountAfterDeposite1);
									break;	
						
								case 5:
									System.out.println("1.Account to wallet\n2.wallet to account\n3.Wallet to wallet");
									int c=0;
									c=scan.nextInt();
									switch(c) {
									
									
									case 1:
										int Account_number5; double amount11;
										System.out.println("Enter Account Number: ");
										Account_number5=scan1.nextInt();
										System.out.println("Enter Amount to Transfer: ");
										amount11=scan1.nextDouble();
										String str1 = "";
										try {
											str1 = service.Accounttowallet(Account_number5,amount11);
										} catch (SQLException e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
										System.out.println(str1);
										break;
									case 2:
										int Account_number6; double amount2;
										System.out.println("Enter Account Number: ");
										Account_number6=scan1.nextInt();
										System.out.println("Enter Amount to Transfer: ");
										amount2=scan1.nextDouble();
										String str2 = "";
										try {
											str2 = service.Wallettoaccount(Account_number6,amount2);
										} catch (SQLException e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
										System.out.println(str2);
										break;
										
									case 3:
										int Account_number4,reciever_account_number; double amount1;
										System.out.println("Enter Account Number: ");
										Account_number4=scan1.nextInt();
										System.out.println("Enter Receiver Account Number: ");
										reciever_account_number=scan1.nextInt();
										System.out.println("Enter Amount to Transfer: ");
										amount1=scan1.nextDouble();
										String str = "";
										try {
											str = service.Wallettowallet(Account_number4,reciever_account_number,amount1);
										} catch (SQLException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
										System.out.println(str);
										break;
									
									}
							break;
								case 6:
									System.out.println("Enter your account number");
									Account_number=scan.nextInt();
						List<Transaction> list = null;
						try {
							list = service.printtransaction(Account_number);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
									list.stream().forEach(System.out::println);
									break;
									
								case 7:
									System.out.println("****Thank you*****");
									System.exit(0);
									break;
									
					}
					
				}catch(InputMismatchException e) {
					choiceFlag=false;
					System.err.println("Please Enter digits");
				}
				
			}while(!choiceFlag);
			scan=new Scanner(System.in);
			System.out.println("Do you want to continue again [yes/no]");
			ContinueChoice=scan.nextLine();
			
		}while(ContinueChoice.equalsIgnoreCase("yes"));
		scan.close();
		scan1.close();
		
	}

}
