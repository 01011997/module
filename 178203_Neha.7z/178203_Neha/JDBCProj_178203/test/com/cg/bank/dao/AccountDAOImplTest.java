package com.cg.bank.dao;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.AccountException;

public class AccountDAOImplTest {
	AccountDAOImpl dao=null;

	@Before
	public void setUp() throws Exception {
		dao=new AccountDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}

	@Test
	public void testAddnewAccount() {
		Account a = new Account("Komal", "12345", "9527192392");
		
	}

	@Test
	public void testGetaccountbalance() throws SQLException {
		int account_number1=0;
		double account=dao.getaccountbalance(account_number1);
		assertNotNull(account);
		
	}

	@Test
	public void testGetwalletbalance() throws SQLException {
		int account_number1=0;
		double wallet=dao.getaccountbalance(account_number1);
		assertNotNull(wallet);
	}

	@Test
	public void testDeposite() throws SQLException {
		int account_number1=0;
		double account=dao.getaccountbalance(account_number1);
		assertNotNull(account);
	}

	@Test
	public void testWithdraw() throws SQLException {
		int account_number1=0;
		double account=dao.getaccountbalance(account_number1);
		assertNotNull(account);
	}

	@Test
	public void testWallettowallet() throws SQLException {
		int account_number1=0;
		double wallet=dao.getaccountbalance(account_number1);
		assertNotNull(wallet);
	}
	

	@Test
	public void testAccounttowallet() throws SQLException {
		int account_number1=0;
		double wallet=dao.getaccountbalance(account_number1);
		assertNotNull(wallet);
	}
	

	@Test
	public void testWallettoaccount() throws SQLException {
		int account_number1=0;
		double account=dao.getaccountbalance(account_number1);
		assertNotNull(account);
	}

}
